# 9. Crie uma sub-rotina que receba como parâmetro um valor inteiro e positivo N e 
# retorne o valor de S, obtido pelo seguinte cálculo: 

def calcular_s(n):

  if not isinstance(n, int) or n < 1:
    raise ValueError("O valor de n deve ser um inteiro positivo.")

  s = 1.0
  fatorial = 1.0
  for i in range(1, n + 1):
    fatorial *= i
    s += 1.0 / fatorial

  return s

def main():
    x = int(input("Digite um valor: "))
    v = calcular_s(x)

    print(f"O valor de S para n = {x} é: {v}")

main()
