# Faça uma sub-rotina que receba um único valor representando segundos. Essa sub-rotina
# deverá convertê-lo para horas, minutos e segundos. Todas as variáveis devem ser passadas
# como parâmetro, não havendo variáveis globais.

def converter_segundos(segundos):
  horas = segundos // 3600
  segundos_restantes = segundos % 3600
  minutos = segundos_restantes // 60
  segundos_restantes = segundos_restantes % 60
  return horas, minutos, segundos_restantes

def main():

    seg = int(input("Digite a quantidade de segundos: "))
    horas, minutos, segundos = converter_segundos(seg)
    print(f"{seg} segundos equivalem a {horas} horas, {minutos} minutos e {segundos} segundos.")

main()