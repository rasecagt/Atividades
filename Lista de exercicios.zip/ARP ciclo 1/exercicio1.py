#1. Faça um programa contendo uma sub-rotina que retorne 1 se o número digitado for positivo
#ou 0 se for negativo.

def inteiro(p):
    if p > 0:
        return 1
    else:
        return 0
    
def main():
    x = int(input("Digite o número: "))
    print(inteiro(x))

main()
