def ler_dados(habitantes):
  for i in range(5):
    habitante = {}
    habitante["sexo"] = input("Sexo (M/F): ")
    habitante["cor_olhos"] = input("Cor dos olhos (A/C): ")
    habitante["cor_cabelos"] = input("Cor dos cabelos (L/P/C): ")
    habitante["idade"] = int(input("Idade: "))
    habitantes.append(habitante)

def calcular_media_idade_olhos_castanhos_cabelos_pretos(habitantes):
  soma_idades = 0
  numero_pessoas = 0
  for habitante in habitantes:
    if habitante["cor_olhos"] == "C" and habitante["cor_cabelos"] == "P":
      soma_idades += habitante["idade"]
      numero_pessoas += 1
  if numero_pessoas == 0:
    return 0.0
  else:
    return soma_idades / numero_pessoas

def encontrar_maior_idade(habitantes):
  maior_idade = 0
  for habitante in habitantes:
    if habitante["idade"] > maior_idade:
      maior_idade = habitante["idade"]
  return maior_idade

def contar_mulheres_18_35_olhos_azuis_cabelos_louros(habitantes):
  numero_mulheres = 0
  for habitante in habitantes:
    if habitante["sexo"] == "F" and habitante["idade"] >= 18 and habitante["idade"] <= 35 and habitante["cor_olhos"] == "A" and habitante["cor_cabelos"] == "L":
      numero_mulheres += 1
  return numero_mulheres

def main():
    habitantes = []

    ler_dados(habitantes)

    media_idade = calcular_media_idade_olhos_castanhos_cabelos_pretos(habitantes)
    maior_idade = encontrar_maior_idade(habitantes)
    numero_mulheres = contar_mulheres_18_35_olhos_azuis_cabelos_louros(habitantes)

    print(f"Média de idade dos habitantes com olhos castanhos e cabelos pretos: {media_idade:.2f}")
    print(f"Maior idade entre os habitantes: {maior_idade}")
    print(f"Número de mulheres com idade entre 18 e 35 anos, olhos azuis e cabelos louros: {numero_mulheres}")

main()
