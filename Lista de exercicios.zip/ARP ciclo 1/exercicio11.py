# 11. Elabore uma sub-rotina que retorne um vetor com os três primeiros números perfeitos.
# Sabe-se que um número é perfeito quando é igual à soma de seus divisores (exceto ele
# mesmo). Exemplo: os divisores de 6 são 1, 2 e 3, e 1 + 2 + 3 = 6, logo 6 é perfeito.

def encontrar_numeros_perfeitos(n):
  numeros_perfeitos = []
  for i in range(2, 1000000):
    divisores = [1]
    for j in range(2, int(i ** 0.5) + 1):
      if i % j == 0:
        divisores.append(j)
        divisores.append(i // j)
    if sum(divisores) == i:
      numeros_perfeitos.append(i)
      if len(numeros_perfeitos) == n:
        return numeros_perfeitos

def main():
    n = int(input("Digite o valor: "))

    numeros_perfeitos = encontrar_numeros_perfeitos(n)

    print(f"Os {n} primeiros números perfeitos são: {numeros_perfeitos}")

main()