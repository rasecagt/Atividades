# 2. Faça um programa contendo uma sub-rotina que receba dois números positivos por
# parâmetro e retorne a soma dos N números inteiros existentes entre eles.

def sominha(a, b):
    soma = 0
    for i in range(a, b + 1):
        soma += i
    return soma


def main():
    x = int(input("Digite o valor inicial: "))
    y = int(input("Digite o valor final: "))
    if x and y >= 0:
        if x < y:
            awns = sominha(x,y)
            print(awns)
        else:
            awns = sominha(y,x)
            print(awns)
    else:
        print("O número deve ser positivo.")

main()


