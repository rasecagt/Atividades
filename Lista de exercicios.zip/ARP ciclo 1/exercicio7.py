# Elabore um programa contendo uma sub-rotina que receba as três notas de um aluno
# como parâmetros e uma letra. Se a letra for A, a sub-rotina deverá calcular a média
# aritmética das notas do aluno; se for P, deverá calcular a média ponderada, com pesos 5,
# 3 e 2. A média calculada deverá ser devolvida ao programa principal para, então, ser
# mostrada.

def calcular_media(nota1, nota2, nota3, letra):
  if letra == "A":
    media = (nota1 + nota2 + nota3) / 3
  elif letra == "P":
    media = (5 * nota1 + 3 * nota2 + 2 * nota3) / 10
  else:
    raise ValueError("Letra inválida.")
  return media

def main():
    x = int(input("Digite a primeira nota: "))
    y = int(input("Digite a segunda nota: "))
    z = int(input("Digite a ultima nota: "))
    letra = input("Média aritmética ou ponderada? (A/P): ")

    media = calcular_media(x, y, z, letra)

    print(f"A média do aluno é: {media:.2f}")

main()