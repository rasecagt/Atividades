def soma_divisiveis(a, b, c):
  soma = 0
  for i in range(b, c + 1):
    if i % a == 0:
      soma += i
  return soma

def main():
    x = int(input("Digite um valor: "))
    y = int(input("Digite mais um valor: "))
    z = int(input("Digite o ultimo final: "))
    legal = soma_divisiveis(x,y,z)
    print(f"A soma dos números divisíveis por {x} entre {y} e {z} é: {legal}")

main()

