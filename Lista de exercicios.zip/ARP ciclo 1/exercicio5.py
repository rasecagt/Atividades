# Crie um programa que receba os valores antigo e atual de um produto. 
# Chame uma subrotina que determine o percentual de acréscimo entre esses valores.
# O resultado deveráser mostrado no programa principal.

def calcular_acrescimo(valor_antigo, valor_atual):
  if valor_antigo == 0:
    return 0
  else:
    diferenca = valor_atual - valor_antigo
    acrescimo = diferenca / valor_antigo
    return acrescimo * 100

def main():
    x = int(input("Digite o valor antigo: "))
    y = int(input("Digite o valor atual: "))
    acrescimo = calcular_acrescimo(x, y)

    print(f"O percentual de acréscimo foi de {acrescimo}%")

main()