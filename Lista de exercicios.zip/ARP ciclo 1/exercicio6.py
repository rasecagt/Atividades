# Faça uma sub-rotina que receba como parâmetro um inteiro no intervalo de 1 a 9 e mostre
# a seguinte tabela de multiplicação (no exemplo, n = 9):

def imprimir_tabela_multiplicacao(numero):
  print(f"**Tabela de multiplicação do {numero}**")
  print("-" * 20)
  for i in range(1, 11):
    print(f"{numero} x {i:2} = {numero * i:3}")

def main():
    x = int(input("Digite o número: "))
    print(imprimir_tabela_multiplicacao(x))

main()
