# Crie uma sub-rotina que receba como parâmetro a hora de início e a hora de término de um
# jogo, ambas subdivididas em dois valores distintos: horas e minutos. A sub-rotina deverá
# retornar a duração expressa em minutos, considerando que o tempo máximo de duração
# de um jogo é de 24 horas e que ele pode começar em um dia e terminar no outro.

def calcular_duracao_jogo(hora_inicio, minuto_inicio, hora_fim, minuto_fim):
  minutos_inicio = hora_inicio * 60 + minuto_inicio
  minutos_fim = hora_fim * 60 + minuto_fim

  if hora_fim >= hora_inicio:
    duracao = minutos_fim - minutos_inicio

  else:
    duracao = (24 * 60 - minutos_inicio) + minutos_fim

  return duracao

def main():
    hr_in = int(input("Digite a hora inicial: "))
    min_in = int(input("Digite o minuto inicial: "))
    hr_fim = int(input("Digite a hora final: "))
    min_fim = int(input("Digite o minuto final: "))
    duracao = calcular_duracao_jogo(hr_in, min_in, hr_fim, min_fim)

    print(f"A duração do jogo foi de {duracao} minutos.")

main()
